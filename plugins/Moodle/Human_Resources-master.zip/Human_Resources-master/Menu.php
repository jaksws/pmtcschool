<?php
/**
 * Menu.php file
 * Required
 * - Menu entries for the Human Resources module
 *
 * @package Human Resources module
 */
