<?php
/**
 * English Help texts - Email module
 *
 * Texts are organized by:
 * - Module
 * - Profile
 *
 * Please use this file as a reference to generate the Gettext [My_Module]_help.po files
 * and translate Help texts to your language.
 * The Catalog should only reference the Help_en.php file
 * and detect the `_help` function / source keyword.
 *
 * @author François Jacquet
 *
 * @package Email module
 */

// EMAIL ---.
if ( User( 'PROFILE' ) === 'admin' ) :

endif;
